
// OpenGL playground
// Version: glew = 2.1.0; glfw = 3.2.1; glm = 0.9.8.5

#include <iostream>

#include <GL/glew.h>

// You must include glfw/glut/freeglut AFTER glew

#include <GLFW/glfw3.h>

// No need to include gl.h and glu.h
// They are already included in glew.h

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

// Static library vs. dynamic-link library
// When using dll, you must place glew32.dll and glfw3.dll of the SAME version into runtime path

#ifdef GLEW_STATIC
#pragma comment(lib, "glew32s.lib")
#else
#pragma comment(lib, "glew32.lib")
#endif

#ifdef GLFW_STATIC
#pragma comment(lib, "glfw3.lib")
#else
#pragma comment(lib, "glfw3dll.lib")
#endif

// GLM provides GLSL-like data structures and math functions

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

// Vertices' data

static const struct
{
	float x, y;
	float r, g, b;
} vertices[3] = {
	{ -.866f, -.5f, 1.f, 0.f, 0.f },
	{ .866f, -.5f, 0.f, 1.f, 0.f },
	{ 0.f,  1.f, 0.f, 0.f, 1.f }
};

// Shaders' content

static const char* vertex_shader_text =
"#version 330\n"
"uniform mat4 u_mvp;\n"
"in vec2 in_position;\n"
"in vec3 in_color;\n"
"out vec3 pass_color;\n"
"void main()\n"
"{\n"
"    gl_Position = u_mvp * vec4(in_position, 0.0, 1.0);\n"
"    pass_color = in_color;\n"
"}\n";

static const char* fragment_shader_text =
"#version 330\n"
"in vec3 pass_color;\n"
"out vec4 out_color;\n"
"void main()\n"
"{\n"
"    out_color = vec4(pass_color, 1.0);\n"
"}\n";

// Callback functions

static void error_callback(int error, const char* description)
{
	std::cerr << "Error: " << description << std::endl;
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	// When ESC pressed, exit main loop
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
}

int main(int argc, char *argv[])
{
	GLFWwindow* window;
	GLuint vertex_shader, fragment_shader, shader_program;
	GLuint virtual_array_object, virtual_buffer_object;
	GLint mvp_location, position_location, color_location;
	glm::fmat4 model_view_projection(1.0); // Identity matrix

	// Initialize GL environment

	glfwSetErrorCallback(error_callback);

	if (!glfwInit())
		exit(EXIT_FAILURE);

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

	window = glfwCreateWindow(800, 800, "OpenGL output", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		exit(EXIT_FAILURE);
	}

	glfwSetKeyCallback(window, key_callback);

	glfwMakeContextCurrent(window);
	glfwSwapInterval(1); // Turn on V-Sync

	if (glewInit() != GLEW_OK)
	{
		glfwDestroyWindow(window);
		glfwTerminate();
		exit(EXIT_FAILURE);
	}

	// Create shader program

	vertex_shader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertex_shader, 1, &vertex_shader_text, NULL);
	glCompileShader(vertex_shader);

	fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragment_shader, 1, &fragment_shader_text, NULL);
	glCompileShader(fragment_shader);

	shader_program = glCreateProgram();
	glAttachShader(shader_program, vertex_shader);
	glAttachShader(shader_program, fragment_shader);
	glLinkProgram(shader_program);

	int linkStatus;
	glGetProgramiv(shader_program, GL_LINK_STATUS, &linkStatus);
	if (linkStatus == GL_FALSE)
	{
		std::cout << "Error occured while linking shader program." << std::endl;
		char infoLog[1024] = { 0 };
		glGetProgramInfoLog(shader_program, 1024, NULL, infoLog);
		std::cout << infoLog << std::endl;
	}

	glDetachShader(shader_program, vertex_shader);
	glDetachShader(shader_program, fragment_shader);
	glDeleteShader(vertex_shader);
	glDeleteShader(fragment_shader);

	// Create virtual array object

	glGenVertexArrays(1, &virtual_array_object);
	glBindVertexArray(virtual_array_object);

	glGenBuffers(1, &virtual_buffer_object);
	glBindBuffer(GL_ARRAY_BUFFER, virtual_buffer_object);

	// Set up attributes

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	mvp_location = glGetUniformLocation(shader_program, "u_mvp");
	position_location = glGetAttribLocation(shader_program, "in_position");
	if (position_location >= 0)
	{
		glEnableVertexAttribArray(position_location);
		glVertexAttribPointer(position_location, 2, GL_FLOAT, GL_FALSE, sizeof(vertices[0]),
			(const void *)((char *)&vertices[0].x - (char *)&vertices[0]));
	}
	color_location = glGetAttribLocation(shader_program, "in_color");
	if (color_location >= 0)
	{
		glEnableVertexAttribArray(color_location);
		glVertexAttribPointer(color_location, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]),
			(const void *)((char *)&vertices[0].r - (char *)&vertices[0]));
	}

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	// Enable depth test

	glEnable(GL_DEPTH_TEST);

	// Start main loop

	while (!glfwWindowShouldClose(window))
	{
		int width, height;
		float ratio;

		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;

		// Make the triangle rotate by changing matrix
		model_view_projection *= glm::rotate(glm::fmat4(), 3.1416f / 60.f, glm::fvec3(0.0, 0.0, 1.0));

		// Set viewport in window
		glViewport(0, 0, width, height);

		// Clear buffers so the new frame can be displayed correctly
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Set shader program and vao
		glUseProgram(shader_program);
		glBindVertexArray(virtual_array_object);

		// Pass uniform value
		glUniformMatrix4fv(mvp_location, 1, GL_FALSE, (const GLfloat *)&model_view_projection);
		// Draw a triangle
		// * If index buffer enabled, call glDrawElements()
		glDrawArrays(GL_TRIANGLES, 0, 3);

		glBindVertexArray(0);
		glUseProgram(0);

		// Don't forget to swap front and back buffers
		glfwSwapBuffers(window);

		// Poll events and (possibly) call callback functions
		glfwPollEvents();
	}

	glfwDestroyWindow(window);

	glfwTerminate();
	exit(EXIT_SUCCESS);
}