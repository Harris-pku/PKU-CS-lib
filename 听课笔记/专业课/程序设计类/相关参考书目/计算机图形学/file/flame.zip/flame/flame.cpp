#define _USE_MATH_DEFINES

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include <fstream>
#include <iterator>
#include <string>

#include <GL/glew.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <FreeImagePlus.h>

#include <GL/glut.h>

int windowWidth = 1024, windowHeight = 576;

GLuint program = 0;
GLuint texture = 0;

using namespace glm;

struct FlameParticle
{
	double life;            // ʣ������
	double fade;            // ˥������
	double size;            // ��С
	double angle;           // ��ת
	dvec3 pos;              // λ��
	dvec3 vel;              // �ٶ�
	vec3 colorFirst;        // ��ʼ��ɫ
	vec3 colorEnd;          // ĩ����ɫ
};

int const NUM_PARTICLES = 300;

FlameParticle particles[NUM_PARTICLES];

dvec3 const INIT_POS(0, 0, 0);
dvec3 const INIT_VEL = normalize(dvec3(-1, 0, -1)) * 5.0;
double const INIT_SIZE = 0.1;
double const SIZE_SCALING = 1.0;
double const ROT_SPEED = M_PI / 0.1;

double randomFade()
{
	double duration = double(rand()) / RAND_MAX * 0.5 + 0.5;
	return 1.0 / duration;
}

double randDouble()
{
	return rand() / double(RAND_MAX);
}

void initParticle(FlameParticle &p)
{
	p.life = 1.0;
	p.fade = randomFade();
	p.size = INIT_SIZE;
	p.angle = randDouble() * 2.0 * M_PI;
	p.pos = INIT_POS;
	p.vel = INIT_VEL;
	p.colorFirst = vec3(0.8, 0.2, 0.0);
	p.colorEnd = vec3(0.5, 0.2, 0.0);
}

dvec3 randomOffset()
{
	return vec3(randDouble(), randDouble(), randDouble());
}

void step(FlameParticle &p, double delta_t)
{
	p.life -= p.fade * delta_t;
	if(p.life <= 0.0)
		initParticle(p);
	else
	{
		p.pos += p.vel * randomOffset() * delta_t;
		p.angle += ROT_SPEED * randDouble() * delta_t;
		p.size += SIZE_SCALING * delta_t;
	}
}

void checkGL()
{
	glFinish();
	GLenum error = glGetError();
	assert(error == GL_NO_ERROR);
}

GLuint loadShaderSource(const char *path, GLenum type)
{
	GLuint shader = glCreateShader(type);

	std::ifstream file(path);
	std::string sourceString((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
	const char *sourcePointers[1] = {sourceString.c_str()};

	glShaderSource(shader, 1, sourcePointers, nullptr);
	glCompileShader(shader);

	char msg[1024] = "";
	glGetShaderInfoLog(shader, sizeof(msg), nullptr, msg);
	std::fprintf(stderr, "%s\n", msg);

	return shader;
}

void init()
{
	GLuint vShader = loadShaderSource("flame.vert", GL_VERTEX_SHADER);
	GLuint gShader = loadShaderSource("flame.geom", GL_GEOMETRY_SHADER);
	GLuint fShader = loadShaderSource("flame.frag", GL_FRAGMENT_SHADER);

	program = glCreateProgram();
	glAttachShader(program, vShader);
	glAttachShader(program, gShader);
	glAttachShader(program, fShader);
	glBindAttribLocation(program, 0, "p_pos");
	glBindAttribLocation(program, 1, "p_size");
	glBindAttribLocation(program, 2, "p_color");
	glBindAttribLocation(program, 3, "p_rotation");
	glLinkProgram(program);

	char msg[1024] = "";
	glGetProgramInfoLog(program, sizeof(msg), nullptr, msg);
	std::fprintf(stderr, "%s\n", msg);

	glDeleteShader(vShader);
	glDeleteShader(gShader);
	glDeleteShader(fShader);

	fipImage image;
	image.load("particle.png");
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, image.getWidth(), image.getHeight(),
		0, GL_RED, GL_UNSIGNED_BYTE, image.accessPixels());
	glGenerateMipmap(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, 0);

	for(int i = 0; i < NUM_PARTICLES; ++i)
		initParticle(particles[i]);
	
	// Ԥ�ȵ��� 100 ֡���ﵽ�ȽϾ��ȵķֲ�������Ϊ��ʾʹ��
	for(int i = 0; i < 100; ++i)
	{
		for(int j = 0; j < NUM_PARTICLES; ++j)
			step(particles[j], 1.0 / 60.0);
	}

	checkGL();
}

void display()
{
	glClearColor(0, 0, 0, 0);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	dmat4 viewMatrix = lookAt(dvec3(0, -10, 0), dvec3(0, 0, 0), dvec3(0, 0, 1));
	dmat4 projMatrix = perspective(M_PI / 4, double(windowWidth) / windowHeight, 0.1, 100.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixd(value_ptr(viewMatrix));
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(value_ptr(projMatrix));
	glMatrixMode(GL_MODELVIEW);
	glBindTexture(GL_TEXTURE_2D, texture);

	glEnable(GL_BLEND);
	glBlendEquation(GL_FUNC_ADD);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glUseProgram(program);
	glBegin(GL_POINTS);
	for(int i = 0; i < NUM_PARTICLES; ++i)
	{
		FlameParticle const& p = particles[i];
		vec3 color = mix(p.colorEnd, p.colorFirst, p.life);
		glVertexAttrib1f(1, p.size);
		glVertexAttrib4f(2, color.r, color.g, color.b, p.life);
		glVertexAttrib1f(3, p.angle);
		glVertexAttrib3f(0, p.pos.x, p.pos.y, p.pos.z);
	}
	glEnd();
	glUseProgram(0);

	glDisable(GL_BLEND);

	glBindTexture(GL_TEXTURE_2D, 0);

	for(int i = 0; i < NUM_PARTICLES; ++i)
	{
		step(particles[i], 1.0 / 60.0);
	}

	checkGL();

	glutSwapBuffers();
	glutPostRedisplay();
}

void reshape(int width, int height)
{
	windowWidth = width;
	windowHeight = height;
	glViewport(0, 0, width, height);
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_ALPHA | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowSize(windowWidth, windowHeight);
	glutCreateWindow("OpenGL Window");

	glewInit();
	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);

	glutMainLoop();

	return 0;
}
